package com.example.karyawan.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaryawanApplicationTests {

	@Test
	void contextLoads() {
	}

}
